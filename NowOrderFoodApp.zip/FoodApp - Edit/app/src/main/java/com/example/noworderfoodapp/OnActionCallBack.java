package com.example.noworderfoodapp;

public interface OnActionCallBack {
    void callBack(String key, Object data);
}
