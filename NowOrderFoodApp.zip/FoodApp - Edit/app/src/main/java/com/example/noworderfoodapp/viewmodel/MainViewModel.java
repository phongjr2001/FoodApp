package com.example.noworderfoodapp.viewmodel;

import androidx.lifecycle.ViewModel;

public class MainViewModel extends ViewModel {
}
